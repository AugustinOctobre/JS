

// document.getElementById("infos").innerHTML=randomNumber

// randomNumber = Math.floor(Math.random() * 10 + 1);
// console.log (getRandomInt (10));

let Atrouver = getRandomInt(10);
console.log(Atrouver);
console.log(getRandomInt(10));
let Proposition=Number(prompt("Nombre entre 1 et 10?"));


    if (Proposition == Atrouver) {
        document.getElementById("infos").innerHTML="gagné";
    }else{
        document.getElementById("infos").innerHTML="perdu";
    }  
// ---------------------
    function getRandomInt (max) {
        return Math.floor(math.random() * max + 1) ;
    }
    

