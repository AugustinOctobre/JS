
function getRandomInt (max) {
    return Math.floor(math.random() * max + 1) ;
}

console.log(getElementById(10))